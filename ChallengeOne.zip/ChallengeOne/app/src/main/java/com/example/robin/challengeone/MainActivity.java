package com.example.robin.challengeone;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void picChange(View view) {
        //This site was used a lot for help with code:
        //https://developer.android.com/guide/topics/ui/controls/radiobutton.html#HandlingEvents

        ImageView iv = findViewById(R.id.imageView);
        boolean picked=((RadioButton) view).isChecked();
        switch(view.getId()) {
            case R.id.coati:
                if (picked)
                    //picture change
                    iv.setImageDrawable(getResources().getDrawable(R.drawable.coati));
                    //from this site:
                    //https://stackoverflow.com/questions/8642823/using-setimagedrawable-dynamically-to-set-image-in-an-imageview
                    break;
            case R.id.sheep:
                if (picked)
                    iv.setImageDrawable(getResources().getDrawable(R.drawable.sheep));
                    break;
            case R.id.chimpanzee:
                if (picked)
                    iv.setImageDrawable(getResources().getDrawable(R.drawable.chimpanzee));
                    break;
            case R.id.chipmunk:
                if (picked)
                    iv.setImageDrawable(getResources().getDrawable(R.drawable.chipmunk));
                    break;
        }

    }
}
